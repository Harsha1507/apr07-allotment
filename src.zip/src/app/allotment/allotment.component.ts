import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { AllotmentService } from '../allotment.service';

@Component({
  selector: 'app-allotment',
  templateUrl: './allotment.component.html',
  styleUrls: ['./allotment.component.css']
})
export class AllotmentComponent implements OnInit {
  allotmentForm:any;
  allotments:any;
  constructor(private fb:FormBuilder, private as:AllotmentService) {
    
   }

  ngOnInit(): void {
    this.getAllAllotment();
  }
  getAllAllotment(){
    this.as.getAllAllotment().subscribe((data)=>{
      console.log(data);
      this.allotments=data;
    });
  }

  fnApprove(){
    alert("Approved..")
  }


}
