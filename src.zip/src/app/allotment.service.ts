import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class AllotmentService {
  url:string='http://localhost:8080/allotment/';
  constructor(private http:HttpClient) { }

  modifyAllotment(allotment:any)
  {
    return this.http.put(this.url,allotment);
  }
  deleteAllotment(allotmentId:any)
  {
    return this.http.delete(this.url+allotmentId);
  }
  getAllAllotment(){
    return this.http.get(this.url);
  }
  findByAllotmentId(allotmentId:any)
  {
    return this.http.get(this.url+allotmentId);
  }
  addAllotment(allotment:any)
  {
    return this.http.post(this.url,allotment);
  }
}
