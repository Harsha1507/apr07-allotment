package com.hostel_management.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ALLOTMENT")
public class Allotment {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long allotmentId;
	private Long roomId;
	private Long studentId;
	private Date allocationDate;
	transient SimpleDateFormat sdf;
	
	public Allotment() {
		sdf= new SimpleDateFormat("yyyy-MM-dd");
	}

	public Allotment(Long allotmentId, Long roomId, Long studentId, Date allocationDate) {
		this();
		this.allotmentId = allotmentId;
		this.roomId = roomId;
		this.studentId = studentId;
		this.allocationDate = allocationDate;
	}
	

	public Long getAllotmentId() {
		return allotmentId;
	}

	public void setAllotmentId(Long allotmentId) {
		this.allotmentId = allotmentId;
	}

	public Long getRoomId() {
		return roomId;
	}

	public void setRoomId(Long roomId) {
		this.roomId = roomId;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public String getAllocationDate1() {
		return sdf.format(allocationDate);
	}
	

	public Date getAllocationDate() {
		return allocationDate;
	}

	public void setAllocationDate(Date allocationDate) {
		this.allocationDate = allocationDate;
	}

	@Override
	public String toString() {
		return "Allotment [allotmentId=" + allotmentId + ", roomId=" + roomId + ", studentId=" + studentId
				+ ", allocationDate=" + sdf.format(allocationDate) + "]";
	}
	
	

}
