package com.hostel_management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hostel_management.entity.Allotment;
import com.hostel_management.service.AllotmentService;

@RestController
@RequestMapping("/allotment")
@CrossOrigin(origins= {"*"})
public class AllotmentController {
	@Autowired
	private AllotmentService as;
	
	@GetMapping("/")
	public List<Allotment> getAllAllotment()
	{
		List<Allotment> allotmentList = as.read();
		return allotmentList;
	}
	
	@GetMapping("/{allotmentId}")
	public Allotment findByAllotmentId(@PathVariable("allotmentId") Long allotmentId) {
		return as.read(allotmentId);
	}
	
	@PostMapping("/")
	public Allotment addAllotment(@RequestBody Allotment allotment)
	{
		return as.create(allotment);
	}
	
	@PutMapping("/")
	public Allotment modifyAllotment(@RequestBody Allotment allotment)
	{
		return as.update(allotment);
	}
	
	@DeleteMapping("/{allotmentId}")
	public void deleteAllotment(@PathVariable("allotmentId") Long allotmentId)
	{
		as.delete(allotmentId);
	}

}
