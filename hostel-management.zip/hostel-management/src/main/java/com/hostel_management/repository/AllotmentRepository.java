package com.hostel_management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hostel_management.entity.Allotment;

@Repository
public interface AllotmentRepository extends JpaRepository<Allotment, Long>{

}
